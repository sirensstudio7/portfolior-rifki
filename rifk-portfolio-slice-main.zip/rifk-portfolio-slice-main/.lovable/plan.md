

# Rifk Portfolio — Home Page Slice

## Overview
Pixel-accurate recreation of the provided Figma screenshot for the Home page of Rifk's portfolio website.

## Design Details
- **Dark background** (#0a0a0a / near-black) for the entire page
- **Monospace font** for body text (matching the design's typewriter-style look)
- **Green accent color** for the "Let's talk!" button

## Page Structure

### 1. Navigation Bar
- Centered horizontal nav with 5 links: **Home**, Work, Media, Music, Code
- "Home" has a bordered/active state (outlined pill shape)
- Other links are plain text in light gray

### 2. Profile Card
- Dark card (~#1a1a1a) with rounded corners, centered on the page
- Left side: circular avatar (placeholder), name "Rifk", subtitle "Design Engineer" in monospace
- Bottom-left of card: 4 social icon buttons (Instagram, Dribbble, X/Twitter, GitHub) in rounded dark squares
- Right side of card: Two buttons — "Hire Me" (outlined) and "Let's talk!" (green filled)

### 3. About Section
- "// ABOUT" label in small caps/monospace
- Three paragraphs of lorem ipsum-style text in monospace
- Certain words in **bold white** while the rest is in muted gray
- Left-aligned, matching the screenshot's typography exactly

## Technical Approach
- Static, frontend-only page (no backend needed)
- Use Lucide icons for social media where available, or simple SVG icons
- Faithful to the screenshot's spacing, colors, fonts, and layout

